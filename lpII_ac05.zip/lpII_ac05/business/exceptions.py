class ParametroNegativoException(Exception):
  pass

class ParametroZeroException(Exception):
  pass

class OperacaoMuitoFacilException(Exception):
  pass

from business.exceptions import ParametroNegativoException,OperacaoMuitoFacilException,ParametroZeroException

class Calculadora():
    def soma(self,a,b):
        if (a<0 or b<0):
             raise ParametroNegativoException
        return a + b

    def subtracao(self,a,b):
        if (a<0 or b<0):
            raise ParametroNegativoException
        return a - b

    def multiplicacao(self,a,b):
        if (a==1 or b==1):
            raise OperacaoMuitoFacilException
        return a * b

    def divisao(self,a,b):
        if (a==0 or b==0):
            raise ParametroZeroException
        return a / b
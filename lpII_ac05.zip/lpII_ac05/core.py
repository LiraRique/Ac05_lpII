from business.exceptions import ParametroNegativoException,OperacaoMuitoFacilException,ParametroZeroException
from business.models import Calculadora

c=Calculadora()
try:
    print('\n 1 = Soma\n 2 = Subtração\n 3 = Multiplicação\n 4 = Divisão \n')
    usuario= int(input('Escolha a operação matemática que deseja realizar: '))
    if usuario==1:
        a=int(input('Digite o primeiro número para a soma: '))
        b=int(input('Digite o segundo número para a soma: '))
        print("A soma de {} + {} = {}".format(a,b,c.soma(a,b)))
    if usuario == 2:
        a=int(input('Digite o primeiro número para a subtração: '))
        b=int(input('Digite o segundo número para a subtração: '))
        print("A subtração de {} - {} = {}".format(a,b,c.subtracao(a,b)))
    if usuario == 3:
        a=int(input('Digite o primeiro número para a multiplicação: '))
        b=int(input('Digite o segundo número para a multiplicação: '))
        print("A multiplicação de {} * {} = {}".format(a,b,c.multiplicacao(a,b)))
    if usuario == 4:
        a=int(input('Digite o primeiro número para a divisão: '))
        b=int(input('Digite o segundo número para a divisão: '))
        print("A divisao de {} / {} = {}".format(a,b,c.divisao(a,b)))

except ParametroNegativoException:
  print('Não aceitamos números negativos')

except OperacaoMuitoFacilException:
  print('Nãooo! Operação muito facil !!')

except ParametroZeroException:
  print('Não faço divisão com zero')

except Exception:
  print('Ops! Aconteceu Outro erro!')
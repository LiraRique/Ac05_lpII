import pytest
from business import exceptions,models


def test_soma():
    with pytest.raises(exceptions.ParametroNegativoException):
        models.Calculadora().soma(1,-50)

def test_sub():
    with pytest.raises(exceptions.ParametroNegativoException):
        models.Calculadora().subtracao(20, -60)

def test_mult():
    with pytest.raises(exceptions.OperacaoMuitoFacilException):
        models.Calculadora().multiplicacao(20, 1)

def test_divisao():
    with pytest.raises(exceptions.ParametroZeroException):
        models.Calculadora().divisao(0,2)

